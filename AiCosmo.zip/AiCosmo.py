from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

@app.route('/openai', methods=['POST'])
def openai_request():
    data = request.json
    prompt = data['prompt']
    
    # Kirim permintaan ke OpenAI di sini dan dapatkan respons
    # Misalnya menggunakan library requests
    # response = requests.post('https://api.openai.com/v1/engines/davinci/completions', json={'prompt': prompt, 'max_tokens': 50})
    
    # Kirim respons ke ESP32-CAM
    # Contoh respons yang dikirimkan ke ESP32-CAM
    return jsonify({'result': 'Contoh respons dari OpenAI'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
